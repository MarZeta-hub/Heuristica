#!/bin/bash
# -*- ENCODING: UTF-8 -*-
python3 main.py $1 $2