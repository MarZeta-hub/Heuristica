NOTA:
Al ejecutar el ./Cosmos.sh problemaX.prob Y
-Si no deja, hay que darle permisos con chmod 777 

-El primer argumento $1 es el nombre del problema
-El segundo $2 se trata de la heuristica que se quiere usar, puede ser la 0, 1 o la 2
(0 es sin heuristica)
